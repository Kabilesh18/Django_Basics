from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def home(response):
    return HttpResponse ('<h1>This is Home page</h1><br>Kabilesh Home page')
def about(response):
    return HttpResponse('<h1>This is an about page')