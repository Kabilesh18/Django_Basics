from django.urls import path
from .import views

urlpatterns = [
    path('',views.home,name='home'),
    path('checker/',views.checker,name='checker'),
    path('names/',views.names,name='names')
]