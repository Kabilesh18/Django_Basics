from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    return render(request,"home.html")

def checker(request):
    if request.method == 'POST':
        oddeven = int(request.POST.get('oddeven',0))
        return render(request,'checker.html',{'oddeven':oddeven})
    return render(request,"checker.html")

def names(request):
    names = ['hai', 'hello', 'how', 'are', 'you']
    if request.method == 'POST':
        ch = request.POST.get('ch')
        if ch:  # Check if ch is not None
            filter_name = [name for name in names if name.startswith(ch)]
        else:
            filter_name = names  # Show all names if no character provided
        return render(request, 'names.html', {'names': filter_name})
    return render(request, "names.html")