from django.shortcuts import render
from django.http import HttpResponse
from .forms import UserRegistrationForm
# Create your views here.
def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid() :
            username = request.POST.get('username')
            return render(request,'success.html',{'username':username})

    return render(request,'register.html',{'form':form})