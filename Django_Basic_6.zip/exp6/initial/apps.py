from django.apps import AppConfig


class InitialConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'initial'
