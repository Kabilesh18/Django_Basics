from django.shortcuts import render
from django.http import HttpResponse
from django.conf import settings
from django.core.mail import send_mail
# Create your views here.

def mail(request):
    send_mail(
        'Welcome party',
        'Good morning everyone',
        settings.EMAIL_HOST_USER,
        ['kabileshk2003@gmail.com'],
        fail_silently = False,
    )
    return render(request,'success.html')
