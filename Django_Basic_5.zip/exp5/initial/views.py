from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse

# Create your views here.
def set_session(request):
    request.session['fname'] = 'Kabi'
    return HttpResponse("Session data set")

def get_session(request):
    fname1 = request.session.get('fname')
    return HttpResponse(f'The session name is {fname1}')

def set_cookie(request):
    response = HttpResponse('cookie created')
    response.set_cookie('fname','kabilesh')
    return response

def get_cookie(request):
    fname1 = request.COOKIES.get('fname','default_cookie_value')
    return HttpResponse(f'The cookie value is {fname1}')
